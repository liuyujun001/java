import numpy as np

a = np.array([[6, 7, 1], [2, 2, 4]])
print(np.max(a, 1))
print(np.min(a, 1))