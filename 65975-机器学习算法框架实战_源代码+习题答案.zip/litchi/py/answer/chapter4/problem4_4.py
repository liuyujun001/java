import numpy as np
import py.algebra.albebra_util as au

a = np.array([[5, 2, 0], [2, 8, 3], [4, 9, 7]])
print(au.inverse(a))
