import numpy as np

a = np.array([[6, 7, 1], [2, 2, 4]])
b = np.array([[8, 1, 3], [4, 4, 1]])
print(np.add(a, b))
print(np.subtract(a, b))