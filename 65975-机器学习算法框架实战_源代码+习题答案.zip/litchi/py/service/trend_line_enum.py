from enum import Enum

class TrendLineEnum(Enum):
    AUTO = 0
    LINEAR = 1
    LOGRITHM = 2
    EXPONENTIAL = 3
    POLYNOMIAL = 4
    POWER = 5
    MOVING_AVERAGE = 6
