
class Optimizer(object):

    def __init__(self):
        return

    def optimize(self, target_function, params, train_input, truth_output, to_wrap_rmse_function):
        return
