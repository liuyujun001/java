class TargetFunction(object):

    def fun(self, params, args):
        print("target function")
        return
