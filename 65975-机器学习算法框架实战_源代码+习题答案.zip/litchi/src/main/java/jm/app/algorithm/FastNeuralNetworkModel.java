package jm.app.algorithm;

import jm.app.algebra.Matrix;

import java.util.List;
import java.util.Random;

public class FastNeuralNetworkModel {
    Double[][][] weights;
    Double[][] biases;
    Double[][] outputMat;
    int batchSize = 200;
    double lambda = 0.1;
    int epoch = 1000;
    final double RANDOM_COEFFIENCE = 1.0;
    ActivationFunction activationFunction = ActivationFunction.SIGMOID;

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    public double getLambda() {
        return lambda;
    }

    public void setLambda(double lambda) {
        this.lambda = lambda;
    }

    public int getEpoch() {
        return epoch;
    }

    public void setEpoch(int epoch) {
        this.epoch = epoch;
    }

    public void setWeitghts(Double[][][] weights) {
        this.weights = weights;
    }

    public void setBiases(Double[][] biases) {
        this.biases = biases;
    }

    public FastNeuralNetworkModel(int... numOfEachLayer) {
        biases = new Double[numOfEachLayer.length - 1][];
        for (int i = 0; i < biases.length; i++) {
            biases[i] = new Double[numOfEachLayer[i + 1]];
        }

        weights = new Double[numOfEachLayer.length - 1][][];
        for (int i = 0; i < weights.length; i++) {
            weights[i] = new Double[numOfEachLayer[i + 1]][numOfEachLayer[i]];
        }

        outputMat = new Double[numOfEachLayer.length][];
        for (int i = 0; i < outputMat.length; i++) {
            outputMat[i] = new Double[numOfEachLayer[i]];
        }

        init();
    }

    private void init() {
        initWeights();
        initBiases();
    }

    private void initWeights() {
        Random random = new Random();
        for (int i = 0; i < weights.length; i++) {
            for (int j = 0; j < weights[i].length; j++) {
                for (int k = 0; k < weights[i][j].length; k++) {
                    weights[i][j][k] = RANDOM_COEFFIENCE * random.nextDouble();
                }
            }
        }
    }

    private void initBiases() {
        Random random = new Random();
        for (int i = 0; i < biases.length; i++) {
            for (int j = 0; j < biases[i].length; j++) {
                biases[i][j] = RANDOM_COEFFIENCE * random.nextDouble();
            }
        }
    }

    public void train(Matrix[] inputMat, Matrix[] labelMat) {
        double[][] input = new double[inputMat.length][inputMat[0].getRowNum()];
        double[][] label = new double[labelMat.length][labelMat[0].getRowNum()];
        for (int i = 0; i < input.length; i++) {
            for (int j = 0; j < input[0].length; j++) {
                input[i][j] = inputMat[i].getValue(j, 0).doubleValue();
            }
        }
        for (int i = 0; i < label.length; i++) {
            for (int j = 0; j < label[0].length; j++) {
                label[i][j] = labelMat[i].getValue(j, 0).doubleValue();
            }
        }
        train(input, label);
    }

    public void train(double[][] input, double[][] label) {
        for (int i = 0; i < epoch; i++) {
            System.out.println(String.format("Epoch #%d/%d", i+1, epoch));
            for (int j = 0; j < batchSize; j++) {
                int sampleNo = (int) (Math.random() * (input.length - 1));
                double[][] sensitivity = estSensitivity(input, label, sampleNo);
                updateWeights(sensitivity);
                updateBiases(sensitivity);
                //printMse(input, label);
            }
        }
    }

    private void printMse(double[][] input, double[][] label) {
        double sum = 0;
        for (int i = 0; i < input.length; i++) {
            double[] res = forward(input[i]);
            for (int j = 0; j < label[i].length; j++) {
                sum += (res[j] - label[i][j]) * (res[j] - label[i][j]);
            }
        }
        double mse = sum / label.length;
        System.out.println("MSE: " + mse);
    }

    private void updateWeights(double[][] sensitivity) {
        for (int layer = 0; layer < weights.length; layer++) {
            for (int i = 0; i < weights[layer].length; i++) {
                for (int j = 0; j < weights[layer][i].length; j++) {
                    weights[layer][i][j] = weights[layer][i][j] - lambda * sensitivity[layer][i] * outputMat[layer][j];
                }
            }
        }
    }

    private void updateBiases(double[][] sensitivity) {
        for (int layer = 0; layer < biases.length; layer++) {
            for (int i = 0; i < biases[layer].length; i++) {
                biases[layer][i] = biases[layer][i] - lambda * sensitivity[layer][i];
            }
        }
    }

    private double[][] estSensitivity(double[][] input, double[][] label, int sampleNo) {
        double[][] sensitivity = new double[biases.length][];
        for (int i = 0; i < biases.length; i++) {
            sensitivity[i] = new double[biases[i].length];
        }

        double[] output = forward(input[sampleNo]);
        for (int i = 0; i < output.length; i++) {
            sensitivity[sensitivity.length - 1][i] = -2 * derivativeOfActFun(output[i]) * (label[sampleNo][i] - output[i]);
        }

        for (int layer = sensitivity.length - 2; layer >= 0; layer--) {
            for (int i = 0; i < sensitivity[layer].length; i++) {
                sensitivity[layer][i] = derivativeOfActFun(outputMat[layer + 1][i])
                        * innerProduct(selectColumn(weights[layer + 1], i), sensitivity[layer + 1]);
            }
        }
        return sensitivity;
    }

    private int generateSampleNo(double[][] input, int batchSize) {
        Random random = new Random();
        int sampleNo = random.nextInt(input.length);
        return sampleNo;
    }

    private double[] selectColumn(Double[][] mat, int col) {
        double[] vec = new double[mat.length];
        for (int i = 0; i < mat.length; i++) {
            vec[i] = mat[i][col];
        }
        return vec;
    }

    public Matrix forward(Matrix inputMat) {
        double[] input = new double[inputMat.getRowNum()];
        for (int i = 0; i < input.length; i++) {
            input[i] = inputMat.getValue(i, 0).doubleValue();
        }
        double[] output = forward(input);
        Matrix outputMat = new Matrix(output.length, 1);
        for (int i = 0; i < output.length; i++) {
            outputMat.setValue(i, 0, output[i]);
        }
        return outputMat;
    }

    public double[] forward(double[] input) {
        outputMat[0] = convertDoubleArray(input);
        for (int i = 0; i < weights.length; i++) {
            for (int j = 0; j < weights[i].length; j++) {
                outputMat[i + 1][j] = activationFunction(innerProduct(outputMat[i], weights[i][j]) + biases[i][j]);
            }
        }
        return convertDoubleArray(outputMat[outputMat.length - 1]);
    }

    private double activationFunction(double x) {
        switch (activationFunction){
            case SIGMOID: return 1 / (1 + Math.exp(-x));
            case LINEAR: return x;
            default: return x;
        }
    }

    private Double innerProduct(Double[] vec1, Double[] vec2) {
        if (vec1.length != vec2.length) {
            return null;
        }
        return innerProduct(convertDoubleArray(vec1), convertDoubleArray(vec2));
    }

    private Double innerProduct(double[] vec1, double[] vec2) {
        if (vec1.length != vec2.length) {
            return null;
        }
        double res = 0;
        for (int i = 0; i < vec1.length; i++) {
            res += vec1[i] * vec2[i];
        }
        return res;
    }

    private Double[] convertDoubleArray(double[] inputArr) {
        Double[] outputArr = new Double[inputArr.length];
        for (int i = 0; i < outputArr.length; i++) {
            outputArr[i] = inputArr[i];
        }
        return outputArr;
    }

    private double[] convertDoubleArray(Double[] inputArr) {
        double[] outputArr = new double[inputArr.length];
        for (int i = 0; i < outputArr.length; i++) {
            outputArr[i] = inputArr[i];
        }
        return outputArr;
    }

    private double derivativeOfActFun(double output){
        switch (activationFunction){
            case SIGMOID: return output * (1 - output);
            case LINEAR: return 1.0;
            default: return 1.0;
        }
    }

    public ActivationFunction getActivationFunction() {
        return activationFunction;
    }

    public void setActivationFunction(ActivationFunction activationFunction) {
        this.activationFunction = activationFunction;
    }

    public enum ActivationFunction {
        SIGMOID, LINEAR;
    }

    public Matrix[] getOutputMat() {
        Matrix[] matrices = new Matrix[outputMat.length];
        for (int i = 0; i < outputMat.length; i++) {
            Double[] ithOutputMat = outputMat[i];
            Matrix matrix = new Matrix(ithOutputMat.length, 1);
            for (int j = 0; j < ithOutputMat.length; j++) {
                matrix.setValue(j, 0, ithOutputMat[j]);
            }
            matrices[i] = matrix;
        }
        return matrices;
    }
}