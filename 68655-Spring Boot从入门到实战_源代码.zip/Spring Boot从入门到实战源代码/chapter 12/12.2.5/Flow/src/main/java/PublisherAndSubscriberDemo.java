
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.TimeUnit;

public class PublisherAndSubscriberDemo {
    public static void main(String[] args) throws InterruptedException {
        SubmissionPublisher<String> publisher=new SubmissionPublisher<>();
        Flow.Subscriber<String>subscriber=new Flow.Subscriber<String>() {
            private Flow.Subscription subscription;
            @Override
            public void onSubscribe(Flow.Subscription subscription) {
                // 通过 Subscription 和发布者保持订阅关系，并用它来给发布者反馈
                this.subscription=subscription;
//                请求一个数据
                subscription.request(1);
            }
            @Override
            public void onNext(String item) {
                // 接收发布者发布的消息
                System.out.println("【订阅者】接收消息: " + item);
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                this.subscription.request(1);
            }
            @Override
            public void onError(Throwable throwable) {
                // 过程中出现异常会回调这个方法
                System.out.println("【订阅者】数据接收出现异常，" + throwable);

                // 出现异常，取消订阅，告诉发布者我不再接收数据了
                // 实际测试发现，只要订阅者接收消息出现异常，进入了这个回调
                // 订阅者就不会再继续接收消息了
                this.subscription.cancel();
            }
            @Override
            public void onComplete() {
                // 当发布者发出的数据都被接收了，
                // 并且发布者关闭后，会回调这个方法
                System.out.println("【订阅者】数据接收完毕");
            }
        };
        // 3. 发布者和订阅者需要建立关系
        publisher.subscribe(subscriber);
        for (int i=0;i<5;i++){
            String message = "hello flow api " + i;
            System.out.println("【发布者】发布消息: " + message);
            publisher.submit(message);
        }
        publisher.close();
        // main线程延迟关闭，不然订阅者还没接收完消息，线程就被关闭了
        Thread.currentThread().join(20000);
    }
}
