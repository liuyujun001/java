package com.example.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/webFlux")
public class WebFluxApi {
	@GetMapping("/mono")
    public Mono<JSONObject> mono(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", "0");
        jsonObject.put("message", "hello mono!");
        return Mono.just(jsonObject);  //创建Mono对象
    }
    @GetMapping("/flux")
    public Flux<JSONObject> flux(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", "0");
        jsonObject.put("message", "hello flux!");
        return Flux.just(jsonObject);  //创建Mono对象
    }

}
