package com.example.microservice.promotion.service;

import org.springframework.http.ResponseEntity;

import com.example.microservice.promotion.constants.Constant;
import com.example.microservice.promotion.constants.JsonObjectResponse;
import com.example.microservice.promotion.model.PromotionEntity;

import cn.hutool.json.JSONObject;
import reactor.core.publisher.Mono;

public final class FallBackService {
	public static Mono<ResponseEntity<JSONObject>> defaultFallBack(Throwable ex){
    	JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", Constant.ERROR_CODE);
        jsonObject.put("msg", "pushPromotion fallback!");
        return Mono.just(ResponseEntity.ok(jsonObject));
    }
}