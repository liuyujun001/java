package com.example.microservice.promotion.service;

import org.springframework.http.ResponseEntity;

import com.example.microservice.promotion.constants.Constant;
import com.example.microservice.promotion.constants.JsonObjectResponse;
import com.example.microservice.promotion.model.PromotionEntity;

import cn.hutool.json.JSONObject;
import reactor.core.publisher.Mono;
public final class BlockHandlerService {

	public static Mono<ResponseEntity<JSONObject>> promotionPushBlockHandle(Integer id) {
		JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", Constant.ERROR_CODE);
        jsonObject.put("msg", "pushPromotion blcok!");
        return Mono.just(ResponseEntity.ok(jsonObject));
    }
    
	public static Mono<ResponseEntity<JSONObject>> prizeBlockHandle(Integer id, String device) {
		JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", Constant.ERROR_CODE);
        jsonObject.put("msg", "get prize blcok!");
        return Mono.just(ResponseEntity.ok(jsonObject));
    }
}