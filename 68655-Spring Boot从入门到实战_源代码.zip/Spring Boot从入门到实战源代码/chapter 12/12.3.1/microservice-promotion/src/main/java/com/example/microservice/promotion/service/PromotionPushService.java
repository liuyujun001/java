package com.example.microservice.promotion.service;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ReactiveHashOperations;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.example.microservice.promotion.constants.Constant;
import com.example.microservice.promotion.constants.JsonObjectResponse;
import com.example.microservice.promotion.model.PromotionEntity;

import cn.hutool.json.JSONObject;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class PromotionPushService {
	
	@Autowired
    private ReactiveStringRedisTemplate reactiveStringRedisTemplate;
	
	public Mono<ResponseEntity<JSONObject>> pushPromotion(Integer id) {
		String key = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(id));
		ReactiveHashOperations<String, String, String> reactiveHashOperations = reactiveStringRedisTemplate.opsForHash();
		Flux<Entry<String, String>>  flux = reactiveHashOperations.entries(key);
		Map<String, String> map = new HashMap<>();
		flux.subscribe(entry -> {
            String k = entry.getKey();
            String value = entry.getValue();
            map.put(k, value);
        });
        flux.blockLast(Duration.ofMillis(1000)); //先查询，最多阻塞1s
		if (MapUtils.isNotEmpty(map)) {
			String name = (String) map.get("name");
			String prize = (String) map.get("prize");
			Integer beginTime = Integer.valueOf((String) map.get("beginTime"));
			Integer endTime = Integer.valueOf((String) map.get("endTime"));
			Integer currentTime = (int) (System.currentTimeMillis()/1000);
			if (currentTime >= beginTime && currentTime <= endTime) {
				PromotionEntity promotionEntity = new PromotionEntity();
				promotionEntity.setBeginTime(beginTime);
				promotionEntity.setEndTime(endTime);
				promotionEntity.setId(id);
				promotionEntity.setName(name);
				promotionEntity.setPrize(prize);
				log.info("push promotion success");
				JSONObject jsonObject = new JSONObject(promotionEntity);
				return Mono.just(ResponseEntity.ok(jsonObject));
			}
		}
		JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", Constant.ERROR_CODE);
        jsonObject.put("msg", "push promotion error!");
        return Mono.just(ResponseEntity.ok(jsonObject));
	}
	
	public Mono<ResponseEntity<JSONObject>> getPrize(Integer id, String device) {
		String key = MessageFormat.format(Constant.REDIS_PRIZE_KEY, String.valueOf(id), device);
		Mono<String> mono = reactiveStringRedisTemplate.opsForValue().get(key);
		String value = mono.block(Duration.ofMillis(1000));
		if (StringUtils.isEmpty(value)) {
			String promotionKey = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(id));
			ReactiveHashOperations<String, String, String> reactiveHashOperations = reactiveStringRedisTemplate.opsForHash();
			Flux<Entry<String, String>>  flux = reactiveHashOperations.entries(promotionKey);
			Map<String, String> map = new HashMap<>();
			flux.subscribe(entry -> {
	            String k = entry.getKey();
	            String v = entry.getValue();
	            if (StringUtils.equals("prize", k)) {
	            	map.put(k, v);
				}
	        });
	        flux.blockLast(Duration.ofMillis(1000)); //先查询，最多阻塞1s
	        if (MapUtils.isNotEmpty(map)) {
	        	String prize = map.get("prize");
	        	log.info("get prize success");
	        	JSONObject jsonObject = new JSONObject();
	            jsonObject.put("奖品", prize);
	            return Mono.just(ResponseEntity.ok(jsonObject));
	        }
		}
		
		JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", Constant.ERROR_CODE);
        jsonObject.put("msg", "prize is exist!");
        return Mono.just(ResponseEntity.ok(jsonObject));
	}
}
