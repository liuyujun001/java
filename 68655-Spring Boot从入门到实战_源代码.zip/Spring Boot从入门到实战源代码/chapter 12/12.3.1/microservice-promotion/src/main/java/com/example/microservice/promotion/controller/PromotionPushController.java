package com.example.microservice.promotion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.csp.sentinel.EntryType;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.example.microservice.promotion.constants.Constant;
import com.example.microservice.promotion.constants.JsonObjectResponse;
import com.example.microservice.promotion.model.PromotionEntity;
import com.example.microservice.promotion.service.BlockHandlerService;
import com.example.microservice.promotion.service.FallBackService;
import com.example.microservice.promotion.service.PromotionPushService;

import cn.hutool.json.JSONObject;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api")
public class PromotionPushController {
	
	@Autowired
	private PromotionPushService promotionPushService;
	
	@GetMapping("pushPromotion")
	@ResponseBody
	@SentinelResource(value = "pushPromotion", entryType = EntryType.IN, blockHandler = "promotionPushBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public Mono<ResponseEntity<JSONObject>> pushPromotion(Integer id) {
		Mono<ResponseEntity<JSONObject>> mono = Mono.empty();
		try {
			return promotionPushService.pushPromotion(id);
		} catch (Exception e) {
			log.error("push promotion error!");
			JSONObject jsonObject = new JSONObject();
            jsonObject.put("code", Constant.ERROR_CODE);
            jsonObject.put("msg", "push promotion error!");
            return Mono.just(ResponseEntity.ok(jsonObject));
		}
	}
	
	@GetMapping("getPrize")
	@ResponseBody
	@SentinelResource(value = "getPrize", entryType = EntryType.IN, blockHandler = "prizeBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public Mono<ResponseEntity<JSONObject>> getPrize(Integer id, String device) {
		try {
			return promotionPushService.getPrize(id, device);
		} catch (Exception e) {
			log.error("get prize error!");
			JSONObject jsonObject = new JSONObject();
            jsonObject.put("code", Constant.ERROR_CODE);
            jsonObject.put("msg", "get prize error!");
            return Mono.just(ResponseEntity.ok(jsonObject));
		}
	}
}
