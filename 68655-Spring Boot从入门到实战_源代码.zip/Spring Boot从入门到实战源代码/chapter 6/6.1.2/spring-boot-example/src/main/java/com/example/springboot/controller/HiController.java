package com.example.springboot.controller;

import com.example.springboot.service.RateLimitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Autowired
    private RateLimitService rateLimitService;

    @GetMapping("/springBoot")
    public String hi(){
        if(rateLimitService.tryAcquire()){
            return "hi spring boot!";
        }else {
            return "request rateLimit!";
        }
    }
}
