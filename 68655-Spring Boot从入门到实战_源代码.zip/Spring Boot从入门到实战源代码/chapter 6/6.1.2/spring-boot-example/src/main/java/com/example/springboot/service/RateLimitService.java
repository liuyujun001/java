package com.example.springboot.service;

import com.google.common.util.concurrent.RateLimiter;
import org.springframework.stereotype.Service;

@Service
public class RateLimitService {
    private RateLimiter rateLimiter = RateLimiter.create(100.0);

    public boolean tryAcquire(){
        return rateLimiter.tryAcquire();
    }
}
