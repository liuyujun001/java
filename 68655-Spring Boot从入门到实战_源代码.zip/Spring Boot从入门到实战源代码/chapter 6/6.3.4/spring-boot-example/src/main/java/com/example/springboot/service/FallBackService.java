package com.example.springboot.service;

public final class FallBackService {
	public static String defaultFallBack(Throwable ex){
        return "fallback";
    }
}