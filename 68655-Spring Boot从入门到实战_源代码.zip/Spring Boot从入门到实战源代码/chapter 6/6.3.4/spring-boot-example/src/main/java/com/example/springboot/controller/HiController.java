package com.example.springboot.controller;

import com.alibaba.csp.sentinel.EntryType;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.example.springboot.service.BlockHandlerService;
import com.example.springboot.service.FallBackService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class HiController{

    @GetMapping("/springBoot")
    @SentinelResource(value = "hi", entryType = EntryType.IN, blockHandler = "hiBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
    public String hi(){
        return "hi spring boot!";
    }
}
