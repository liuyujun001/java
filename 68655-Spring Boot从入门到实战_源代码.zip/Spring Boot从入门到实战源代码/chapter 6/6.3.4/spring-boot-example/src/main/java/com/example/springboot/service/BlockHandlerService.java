package com.example.springboot.service;

public final class BlockHandlerService {

	public static String hiBlockHandle() {
        return "blcok";
    }
}