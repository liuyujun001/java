package com.example.springboot.controller;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class HiController{

    @GetMapping("/hystrix/test")
    @HystrixCommand(fallbackMethod = "fallback")
    public String hystrixTest(String isFallback) {
        if (StringUtils.equals("1",isFallback)){
            throw new RuntimeException("fallback");
        } else {
            return "hystrix test!";
        }
    }

    public String fallback(String isFallback) {
        return "fallback!!";
    }

}
