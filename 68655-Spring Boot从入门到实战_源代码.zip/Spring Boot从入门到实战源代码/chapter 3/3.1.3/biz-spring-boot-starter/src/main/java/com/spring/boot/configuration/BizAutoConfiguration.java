package com.spring.boot.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring.boot.service.BizService;

@Configuration
@EnableConfigurationProperties(BizProperties.class)
@ConditionalOnProperty("hi.name")
public class BizAutoConfiguration {
	@Bean
	public BizService bizService(BizProperties bizProperties) {
		return new BizService(bizProperties.getName());
	}
}
