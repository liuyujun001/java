package com.spring.boot.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties(prefix="hi")
public class BizProperties {
	private String name;
}
