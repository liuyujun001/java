package com.spring.boot.service;

public class BizService {
	public String name;
	public BizService(String name) {
		this.name = name;
	}
	public String say() {
		return "hi " + this.name;
	}

}
