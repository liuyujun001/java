package com.example.springboot;

import com.example.springboot.controller.HiController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

/**
 * 测试@RunWith
 */
@RunWith(SpringRunner.class)
@WebMvcTest(HiController.class)
public class RunWithTest {
    @Autowired
    private MockMvc mvc;

	@Test
	public void testRunWithExample() throws Exception {
		MvcResult result=mvc.perform(MockMvcRequestBuilders.get("/hi/springBoot")).andReturn();
		MockHttpServletResponse response = result.getResponse();
		String content = response.getContentAsString();
		System.out.println(content);
	}
}