package com.example.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class SpringBootExampleApplicationTests {

	@Test
	public void testHiController() {
		System.out.println("test!!!");
	}

	@Test
	void exampleTest(@Autowired TestRestTemplate restTemplate) {
		String body = restTemplate.getForObject("/hi/springBoot", String.class);
		System.out.println(body);
		assertThat(body).isEqualTo("hi spring boot!");  //返回结果断言
	}

	/**
	 * 通过@AutoConfigureMockMvc
	 * @param mvc
	 * @throws Exception
	 */
	@Test
	public void testRunWithExample(@Autowired MockMvc mvc) throws Exception {
		MvcResult result=mvc.perform(MockMvcRequestBuilders.get("/hi/springBoot")).andReturn();
		MockHttpServletResponse response = result.getResponse();
		String content = response.getContentAsString();
		System.out.println(content);
	}

}