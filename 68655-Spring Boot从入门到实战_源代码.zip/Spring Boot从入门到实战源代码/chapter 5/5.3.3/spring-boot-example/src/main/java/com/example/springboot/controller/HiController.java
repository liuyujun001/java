package com.example.springboot.controller;

import com.alibaba.nacos.api.annotation.NacosInjected;
import com.alibaba.nacos.api.config.annotation.NacosValue;
import com.alibaba.nacos.api.exception.NacosException;
import com.alibaba.nacos.api.naming.NamingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.nacos.api.naming.pojo.Instance;
import java.util.List;

@RestController
@RequestMapping("/hi")
public class HiController{

    @NacosValue(value = "${userName:default}", autoRefreshed = true)
    public String userName;

    //注入NamingService
    @NacosInjected
    private NamingService namingService;

    @GetMapping("/nacos/query")
    public String nacosQuery() {
        return userName;
    }

    @GetMapping("/nacos/service")
    public List<Instance> nacosService(String serviceName) throws NacosException {
        return namingService.getAllInstances(serviceName);
    }

    @GetMapping("/nacos/register")
    public String nacosRegister(String serviceName) throws NacosException {
        namingService.registerInstance("configService","127.0.0.1", 8848);
        return "ok";
    }

}
