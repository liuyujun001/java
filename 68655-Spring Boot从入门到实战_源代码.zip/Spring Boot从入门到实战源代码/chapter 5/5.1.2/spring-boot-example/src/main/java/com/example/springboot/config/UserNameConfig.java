package com.example.springboot.config;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserNameConfig {

    @ApolloConfig
    private Config config;

    @Value("${userName}")
    String userName;

    @ApolloConfigChangeListener
    private void configChangeListter(ConfigChangeEvent changeEvent) {
        if (changeEvent.isChanged("userName")) {
            userName = config.getProperty("userName","springboot");
        }
    }
}
