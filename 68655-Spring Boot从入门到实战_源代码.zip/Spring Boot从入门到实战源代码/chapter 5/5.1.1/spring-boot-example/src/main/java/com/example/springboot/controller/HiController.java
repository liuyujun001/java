package com.example.springboot.controller;

import com.xxl.conf.core.XxlConfClient;
import com.xxl.conf.core.annotation.XxlConf;
import com.xxl.conf.core.listener.XxlConfListener;
import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@RequestMapping("/hi")
public class HiController{

    @XxlConf("default.username")
    public String userName;

    static {
        /**
         * 配置变更监听示例：可开发Listener逻辑，监听配置变更事件；
         */
        XxlConfClient.addListener("default.username", new XxlConfListener(){
            @Override
            public void onChange(String key, String value) throws Exception {
                log.info("配置变更事件通知：{}={}", key, value);
            }
        });
    }

    @GetMapping("/xxl-conf")
    public String hi(){
        return "hi "+userName;
    }
}
