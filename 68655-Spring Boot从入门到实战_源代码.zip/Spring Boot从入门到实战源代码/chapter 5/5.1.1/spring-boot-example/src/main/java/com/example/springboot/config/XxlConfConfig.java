package com.example.springboot.config;

import com.xxl.conf.core.spring.XxlConfFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
public class XxlConfConfig {

    @Value("${xxl.conf.admin.address}")
    private String adminAddress;
    @Value("${xxl.conf.env}")
    private String env;
    @Value("${xxl.conf.access.token}")
    private String accessToken;
    @Value("${xxl.conf.mirrorfile}")
    private String mirrorfile;

    //定义XxlConfGactory
    @Bean
    public XxlConfFactory xxlConfFactory() {
        XxlConfFactory xxlConf = new XxlConfFactory();
        xxlConf.setAdminAddress(adminAddress);  //管理后台路径
        xxlConf.setEnv(env);   //运行环境
        xxlConf.setAccessToken(accessToken);  //设置token
        xxlConf.setMirrorfile(mirrorfile);  //设置镜像文件
        return xxlConf;
    }

}
