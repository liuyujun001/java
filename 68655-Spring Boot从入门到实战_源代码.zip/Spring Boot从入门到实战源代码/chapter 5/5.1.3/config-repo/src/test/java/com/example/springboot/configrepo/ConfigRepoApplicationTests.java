package com.example.springboot.configrepo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigRepoApplicationTests {

	@Test
	void contextLoads() {
	}

}
