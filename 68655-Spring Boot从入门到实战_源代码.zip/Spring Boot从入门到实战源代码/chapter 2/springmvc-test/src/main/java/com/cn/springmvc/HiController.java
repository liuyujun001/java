package com.cn.springmvc;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/hi")
public class HiController {
    @RequestMapping("/say/{id}")
    public ModelAndView sayHi(@RequestBody Integer id, @SessionAttribute String traceId){
        System.out.println(id);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("say");
        modelAndView.addObject("name","mvc");
        return modelAndView;
    }
    @RequestMapping("/forward")
    public String testForward(){
        return "forward:/hi/error";
    }
    @RequestMapping("/redirect")
    public String testRedirect(){
        return "redirect:/hi/error";
    }
}
