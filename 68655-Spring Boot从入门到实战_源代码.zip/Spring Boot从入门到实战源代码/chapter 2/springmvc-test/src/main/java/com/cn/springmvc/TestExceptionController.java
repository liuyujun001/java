package com.cn.springmvc;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class TestExceptionController extends BaseController {
    @RequestMapping("/error")
    public void sayHi(){
        throw new RuntimeException("testExceptionHandler");
    }
}
