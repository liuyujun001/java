package com.cn.springmvc;

import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;

public class BaseController {
    @ExceptionHandler
    public String exception(HttpServletRequest request, Exception ex){
        request.setAttribute("ex", ex);
        if (ex instanceof RuntimeException) {
            return "error";
        } else {
            return "error";
        }

    }
}
