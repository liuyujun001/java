package com.example.promotion.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import lombok.Data;

@Entity
@Table(name="promotion")
@Data
@EntityListeners(AuditingEntityListener.class)
public class PromotionEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;

    @Column(name="name")
    private String name;

    @Column(name="begin_time")
    private Integer beginTime;

    @Column(name="end_time")
    private Integer endTime;
    
    @Column(name="prize")
    private String prize;

    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;
}
