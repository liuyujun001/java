package com.example.promotion.controller;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.csp.sentinel.EntryType;
import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.example.promotion.constants.Constant;
import com.example.promotion.constants.JsonObjectResponse;
import com.example.promotion.model.PromotionEntity;
import com.example.promotion.service.BlockHandlerService;
import com.example.promotion.service.FallBackService;
import com.example.promotion.service.PromotionService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api")
public class PromotionController {
	
	@Autowired
	private PromotionService promotionService;
	
	@GetMapping("queryPromotion")
	@ResponseBody
	@SentinelResource(value = "queryPromotion", entryType = EntryType.IN, blockHandler = "queryPromotionBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public JsonObjectResponse<PromotionEntity> queryPromotion(Integer id) {
		try {
			return promotionService.queryPromotion(id);
		} catch (Exception e) {
			log.error("query promotion error!");
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "query promotion error!");
		}
	}
	
	@PostMapping("addPromotion")
	@ResponseBody
	@SentinelResource(value = "addPromotion", entryType = EntryType.IN, blockHandler = "addPromotionBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public JsonObjectResponse<PromotionEntity> addPromotion(PromotionEntity promotionEntity) {
		if (StringUtils.isBlank(promotionEntity.getName()) || StringUtils.isBlank(promotionEntity.getPrize())) {
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "param is null! ");
		}
		try {
			return promotionService.addPromotion(promotionEntity);
		} catch (Exception e) {
			log.error("add promotion error!");
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "add promotion error!");
		}
	}
	
	@PostMapping("updatePromotion")
	@ResponseBody
	@SentinelResource(value = "updatePromotion", entryType = EntryType.IN, blockHandler = "updatePromotionBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public JsonObjectResponse<PromotionEntity> updatePromotion(PromotionEntity promotionEntity) {
		if (promotionEntity.getId() == null) {
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "id is null! ");
		}
		try {
			return promotionService.updatePromotion(promotionEntity);
		} catch (Exception e) {
			log.error("add promotion error!");
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "add promotion error!");
		}
	}
	
	@DeleteMapping("delPromotion")
	@ResponseBody
	@SentinelResource(value = "delPromotion", entryType = EntryType.IN, blockHandler = "delPromotionBlockHandle", blockHandlerClass = {BlockHandlerService.class}, defaultFallback = "fallback", fallbackClass = {FallBackService.class})
	public JsonObjectResponse<PromotionEntity> delPromotion(Integer id) {
		try {
			return promotionService.delPromotion(id);
		} catch (Exception e) {
			log.error("delete promotion error!");
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "delete promotion error!");
		}
	}
}
