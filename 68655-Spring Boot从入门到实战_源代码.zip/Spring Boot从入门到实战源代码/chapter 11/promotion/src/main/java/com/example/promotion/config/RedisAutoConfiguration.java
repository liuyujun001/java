package com.example.promotion.config;

import java.time.Duration;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.StringRedisTemplate;

@ConditionalOnClass(LettuceConnectionFactory.class)
@Configuration
@EnableConfigurationProperties(RedisProperties.class)
@ConditionalOnProperty("redis.promotion.host")
public class RedisAutoConfiguration {

    @Bean
    @RefreshScope
    public GenericObjectPoolConfig genericObjectPoolConfig(RedisProperties properties) {
        GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
        genericObjectPoolConfig.setMaxTotal(properties.getPromotion().getMaxTotal());
        genericObjectPoolConfig.setMaxIdle(properties.getPromotion().getMaxIdle());
        genericObjectPoolConfig.setMinIdle(properties.getPromotion().getMinIdle());
        genericObjectPoolConfig.setMaxWaitMillis(properties.getPromotion().getMaxWaitMillis());
        genericObjectPoolConfig.setTestOnBorrow(true);
        genericObjectPoolConfig.setTestOnReturn(true);
        genericObjectPoolConfig.setTestWhileIdle(true);
        genericObjectPoolConfig.setTimeBetweenEvictionRunsMillis(properties.getPromotion().getTimeBetweenEvictionRunsMillis());
        return genericObjectPoolConfig;
    }

    @Bean
    @RefreshScope
    public LettuceClientConfiguration lettuceClientConfiguration(RedisProperties properties, GenericObjectPoolConfig genericObjectPoolConfig) {
        LettucePoolingClientConfiguration build = LettucePoolingClientConfiguration.builder()
                .commandTimeout(Duration.ofMillis(properties.getPromotion().getCommandTimeout()))
                .shutdownTimeout(Duration.ZERO)
                .poolConfig(genericObjectPoolConfig)
                .build();
        return build;
    }

    @Bean
    @RefreshScope
    public LettuceConnectionFactory lettuceConnectionFactory(RedisProperties properties,
                                                                         LettuceClientConfiguration lettuceClientConfiguration) {
        RedisStandaloneConfiguration redisConfiguration = new RedisStandaloneConfiguration(properties.getPromotion().getHost(), properties.getPromotion().getPort());
        redisConfiguration.setPassword(properties.getPromotion().getPassword());
        LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisConfiguration, lettuceClientConfiguration);
        return lettuceConnectionFactory;
    }

    @Bean(name = "redisTemplate")
    public StringRedisTemplate stringRedisTemplate(LettuceConnectionFactory lettuceConnectionFactory) {
        return new StringRedisTemplate(lettuceConnectionFactory);
    }
}
