package com.example.promotion.service;

import com.example.promotion.constants.Constant;
import com.example.promotion.constants.JsonObjectResponse;
import com.example.promotion.model.PromotionEntity;

public final class FallBackService {
    public static JsonObjectResponse<PromotionEntity> defaultFallBack(Throwable ex){
    	return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "fallback");
    }
}