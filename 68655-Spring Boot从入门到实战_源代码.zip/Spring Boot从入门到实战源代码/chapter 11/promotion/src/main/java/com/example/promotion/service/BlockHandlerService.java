package com.example.promotion.service;

import com.example.promotion.constants.Constant;
import com.example.promotion.constants.JsonObjectResponse;
import com.example.promotion.model.PromotionEntity;

public final class BlockHandlerService {

    public static JsonObjectResponse<PromotionEntity> queryPromotionBlockHandle(Integer id) {
    	return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "queryPromotion blcok");
    }
    
    public static JsonObjectResponse<PromotionEntity> addPromotionBlockHandle(PromotionEntity promotionEntity) {
    	return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "addPromotion blcok");
    }
    
    public static JsonObjectResponse<PromotionEntity> updatePromotionBlockHandle(PromotionEntity promotionEntity) {
    	return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "updatePromotion blcok");
    }
    
    public static JsonObjectResponse<PromotionEntity> delPromotionBlockHandle(Integer id) {
    	return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "delPromotion blcok");
    }
}