package com.example.promotion.service;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.example.promotion.constants.Constant;
import com.example.promotion.constants.JsonObjectResponse;
import com.example.promotion.model.PromotionEntity;
import com.example.promotion.repository.PromotionRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PromotionService {
	@Autowired
    private PromotionRepository promotionRepository;
	
	@Autowired
    private StringRedisTemplate stringRedisTemplate;
	
	public JsonObjectResponse<PromotionEntity> queryPromotion(Integer id) {
		Optional<PromotionEntity> promotionEntity = promotionRepository.findById(id);
		if (promotionEntity.isPresent()) {
			return new JsonObjectResponse<>(promotionEntity.get());
		} else {
			return new JsonObjectResponse<>(null);
		}
	}
	
	public JsonObjectResponse<PromotionEntity> addPromotion(PromotionEntity promotionEntity) {
		PromotionEntity promotionEntityOld = promotionRepository.findByName(promotionEntity.getName());
		if (promotionEntityOld != null) {
			return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "promotion name is exist!");
		} else {
			PromotionEntity promotionEntityNew = promotionRepository.save(promotionEntity);
			String key = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(promotionEntityNew.getId()));
			Map<String, String> map = new HashMap<>();
			map.put("name", promotionEntityNew.getName());
			map.put("beginTime", String.valueOf(promotionEntityNew.getBeginTime()));
			map.put("endTime", String.valueOf(promotionEntityNew.getEndTime()));
			map.put("prize", promotionEntityNew.getPrize());
			stringRedisTemplate.opsForHash().putAll(key, map);
			log.info("addPromotion success");
		}
		return new JsonObjectResponse<>(null);
	}
	
	public JsonObjectResponse<PromotionEntity> updatePromotion(PromotionEntity promotionEntity) {
		Optional<PromotionEntity> promotionEntityOpt = promotionRepository.findById(promotionEntity.getId());
		if (promotionEntityOpt.isPresent()) {
			PromotionEntity promotionEntityOld = promotionEntityOpt.get();
			promotionEntityOld.setName(promotionEntity.getName());
			promotionEntityOld.setPrize(promotionEntity.getPrize());
			promotionEntityOld.setBeginTime(promotionEntity.getBeginTime());
			promotionEntityOld.setEndTime(promotionEntity.getEndTime());
			promotionRepository.save(promotionEntityOld);
			String key = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(promotionEntityOld.getId()));
			Map<String, String> map = new HashMap<>();
			map.put("name", promotionEntityOld.getName());
			map.put("beginTime", String.valueOf(promotionEntityOld.getBeginTime()));
			map.put("endTime", String.valueOf(promotionEntityOld.getEndTime()));
			map.put("prize", promotionEntityOld.getPrize());
			stringRedisTemplate.opsForHash().putAll(key, map);
			log.info("updatePromotion success");
		}
		return new JsonObjectResponse<>(null);
	}
	
	public JsonObjectResponse<PromotionEntity> delPromotion(Integer id) {
		promotionRepository.deleteById(id);
		String key = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(id));
		stringRedisTemplate.delete(key);
		log.info("delPromotion success");
		return new JsonObjectResponse<>(null);
	}

}
