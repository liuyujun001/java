package com.example.promotion.constants;

public class JsonObjectResponse<T> extends AbstractResponse {

	private T result;

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}

	public JsonObjectResponse(T result, String code, String msg) {
		this.setCode(code);
		this.setMsg(msg);
		this.result = result;
	}

	public JsonObjectResponse(T result) {
		this.setCode(Constant.SUCCESS_CODE);
		this.setMsg(Constant.SUCCESS_MSG);
		this.result = result;
	}

	public JsonObjectResponse() {
		this.setCode(Constant.SUCCESS_CODE);
		this.setMsg(Constant.SUCCESS_MSG);
		this.result = null;
	}

	public JsonObjectResponse(String code, String msg) {
		this.setCode(code);
		this.setMsg(msg);
	}
}
