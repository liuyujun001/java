package com.example.microservice.promotion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicePromotionApplicationTests {

	@Test
	void contextLoads() {
	}

}
