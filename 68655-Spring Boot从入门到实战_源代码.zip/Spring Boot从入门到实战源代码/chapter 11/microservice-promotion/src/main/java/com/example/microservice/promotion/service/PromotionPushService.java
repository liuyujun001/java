package com.example.microservice.promotion.service;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ReactiveHashOperations;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.example.microservice.promotion.constants.Constant;
import com.example.microservice.promotion.constants.JsonObjectResponse;
import com.example.microservice.promotion.model.PromotionEntity;

import cn.hutool.json.JSONObject;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class PromotionPushService {
	
	@Autowired
    private StringRedisTemplate stringRedisTemplate;
	
	public JsonObjectResponse<PromotionEntity> pushPromotion(Integer id) {
		String key = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(id));
		Map<Object, Object> map = stringRedisTemplate.opsForHash().entries(key);
		if (MapUtils.isNotEmpty(map)) {
			String name = (String) map.get("name");
			String prize = (String) map.get("prize");
			Integer beginTime = Integer.valueOf((String) map.get("beginTime"));
			Integer endTime = Integer.valueOf((String) map.get("endTime"));
			Integer currentTime = (int) (System.currentTimeMillis()/1000);
			if (currentTime >= beginTime && currentTime <= endTime) {
				PromotionEntity promotionEntity = new PromotionEntity();
				promotionEntity.setBeginTime(beginTime);
				promotionEntity.setEndTime(endTime);
				promotionEntity.setId(id);
				promotionEntity.setName(name);
				promotionEntity.setPrize(prize);
				log.info("push promotion success");
				JSONObject jsonObject = new JSONObject(promotionEntity);
				return new JsonObjectResponse<>(promotionEntity);
			}
		}
		return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "push promotion fail");
	}
	
	public JsonObjectResponse<String> getPrize(Integer id, String device) {
		String key = MessageFormat.format(Constant.REDIS_PRIZE_KEY, String.valueOf(id), device);
		String value = stringRedisTemplate.opsForValue().get(key);
		if (StringUtils.isEmpty(value)) {
			String promotionKey = MessageFormat.format(Constant.REDIS_PROMOTION_KEY, String.valueOf(id));
			Map<Object, Object> map = stringRedisTemplate.opsForHash().entries(promotionKey);
			if (MapUtils.isNotEmpty(map)) {
				String prize = (String) map.get("prize");
				stringRedisTemplate.opsForValue().set(key, "1");
				log.info("get prize success");
				return new JsonObjectResponse<>("恭喜你获得:" + prize);
			}
		}
		return new JsonObjectResponse<>(null, Constant.ERROR_CODE, "prize is exist");
	}
}
