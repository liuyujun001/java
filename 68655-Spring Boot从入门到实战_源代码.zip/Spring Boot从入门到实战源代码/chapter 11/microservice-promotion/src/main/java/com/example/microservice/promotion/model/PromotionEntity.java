package com.example.microservice.promotion.model;

import java.io.Serializable;
import lombok.Data;

@Data
public class PromotionEntity implements Serializable {

	private static final long serialVersionUID = 1L;

    private Integer id;

    private String name;

    private Integer beginTime;

    private Integer endTime;
    
    private String prize;
}
