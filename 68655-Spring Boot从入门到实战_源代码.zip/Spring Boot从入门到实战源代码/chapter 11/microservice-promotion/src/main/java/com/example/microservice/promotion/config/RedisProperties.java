package com.example.microservice.promotion.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "redis")
public class RedisProperties {

    private RedisInfo promotion;

    @Data
    public static class RedisInfo{
        protected int maxTotal = 2000;
        protected int maxIdle = 100;
        protected int minIdle = 40;
        protected int maxWaitMillis = 3000;
        protected int timeBetweenEvictionRunsMillis = 30000;
        protected int commandTimeout = 3000;
        private String host;
        private int port;
        private String password;
    }

}
