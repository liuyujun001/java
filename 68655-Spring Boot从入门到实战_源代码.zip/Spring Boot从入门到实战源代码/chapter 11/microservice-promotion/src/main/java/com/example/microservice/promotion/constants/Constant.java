package com.example.microservice.promotion.constants;

public class Constant {

	public static final String SUCCESS_CODE = "S00000";
	public static final String ERROR_CODE = "F00001";
	public static final String SUCCESS_MSG = "success";
	public static final String REDIS_PROMOTION_KEY = "promotion:{0}";
	public static final String REDIS_PRIZE_KEY = "promotion:{0}:{1}";
}