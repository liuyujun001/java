package com.example.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/restTemplate/query")
    public String hi(){
        return "spring boot!";
    }

    @GetMapping("/restTemplate/test")
    public String restTemplateTest(){
        String result = restTemplate.getForObject("http://localhost:8080/hi/restTemplate/query",String.class);
        return result;
    }
}
