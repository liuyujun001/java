package com.example.springboot.controller;

//import com.spring.boot.service.BizService;

import com.example.springboot.mapper.UserMapper;
import com.example.springboot.model.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Resource
    private UserMapper userMapper;

    @GetMapping("/mybatis/findOne")
    public User mybatisFindOne(Integer userId) {
        User user = userMapper.selectByPrimaryKey(userId);
        return user;
    }

}
