CREATE database if NOT EXISTS `test_db` default character set utf8 collate utf8_general_ci;
use `test_db`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '�û�id',
  `user_name` varchar(128) NOT NULL COMMENT '�û��ǳ�',
  `login_name` varchar(128) NOT NULL COMMENT '��¼�˻�',
  `user_head_img` varchar(256) DEFAULT NULL COMMENT '�û�ͷ��',
  `last_login_time` int(11) DEFAULT NULL COMMENT '�ϴε�¼ʱ��'
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
