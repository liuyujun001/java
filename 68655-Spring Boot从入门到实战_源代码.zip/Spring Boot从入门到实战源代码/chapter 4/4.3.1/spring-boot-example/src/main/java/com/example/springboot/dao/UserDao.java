package com.example.springboot.dao;

import com.example.springboot.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public String add(User user){
        String sql = "insert into user(user_name, login_name, last_login_time, user_head_img) value (?, ?, ?, ?)";
        try {
            jdbcTemplate.update(sql,user.getUserName(),user.getLoginName(),user.getLastLoginTime(),user.getUserHeadImg());
            return "1";
        } catch (DataAccessException e) {
            e.printStackTrace();
            return "0";
        }
    }

    public User findOne(Integer userId){
        String sql = "select * from user where user_id = " + userId;
        List<User> userList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class));
        return userList.get(0);
    }

    public String update(User user){
        String sql = "update user set user_name = ?, login_name = ? where user_id = ?";
        try {
            jdbcTemplate.update(sql, user.getUserName(), user.getLoginName(), user.getUserId());
            return "1";
        } catch (DataAccessException e) {
            return "0";
        }
    }

    public String delete(Integer userId){
        String sql = "delete from user where user_id = ?";
        try {
            jdbcTemplate.update(sql, userId);
            return "1";
        } catch (DataAccessException e) {
            return "0";
        }
    }

    public List<User> findAll(){
        String sql = "select * from user";
        List<User> query = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(User.class));
        return query;
    }


}
