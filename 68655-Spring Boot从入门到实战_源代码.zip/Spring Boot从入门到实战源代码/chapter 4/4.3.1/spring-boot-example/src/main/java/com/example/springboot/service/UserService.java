package com.example.springboot.service;

import com.example.springboot.dao.UserDao;
import com.example.springboot.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    public String add(User user){
        return userDao.add(user);
    }

    @Cacheable(value="user")
    public User findOne(Integer userId){
        return userDao.findOne(userId);
    }

    public String update(User user){
        return userDao.update(user);
    }

    @CacheEvict(value="user")
    public String delete(Integer userId){
        return userDao.delete(userId);
    }

    @CachePut(value="userAll")
    public List<User> findAll(){
        return userDao.findAll();
    }


}
