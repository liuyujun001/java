package com.example.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @GetMapping("/redis/add")
    public String redisAdd(int id) {
        stringRedisTemplate.opsForValue().set("redis_test_"+id, "redis test!");
        return "1";
    }

    @GetMapping("/redis/query")
    public String redisQuery(int id) {
        String val = stringRedisTemplate.opsForValue().get("redis_test_"+id);
        return val;
    }

    @GetMapping("/redis/delete")
    public String redisDelete(int id) {
        stringRedisTemplate.delete("redis_test_"+id);
        return "1";
    }
}
