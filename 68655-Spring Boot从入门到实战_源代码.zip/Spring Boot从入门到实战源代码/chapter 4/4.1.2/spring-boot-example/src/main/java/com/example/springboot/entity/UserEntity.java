package com.example.springboot.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Table(name="user")
@Data
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_id")
    private Integer userId;

    @Column(name="user_name")
    private String userName;

    @Column(name="login_name")
    private String loginName;

    @Column(name="last_login_time")
    private Integer lastLoginTime;

    @Column(name="user_head_img")
    private String userHeadImg;
}
