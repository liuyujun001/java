package com.example.springboot.controller;

import com.example.springboot.dao.UserRepository;
import com.example.springboot.entity.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/jpa/findOne")
    public UserEntity jpaFindOne(Integer userId) {
        Optional<UserEntity> optional = userRepository.findById(userId);
        if (optional.isPresent()) {
            return optional.get();
        } else {
            return null;
        }
    }

    @GetMapping("/jpa/findAll")
    public Page<UserEntity> jpaFindAll() {
        Pageable pageable = PageRequest.of(1,2, Sort.by(Sort.Direction.DESC,"userId"));
        userRepository.findAll();
        Page<UserEntity> page = userRepository.findAll(pageable);
        return page;
    }

    @PostMapping("/jpa/add")
    public UserEntity jpaAdd(@RequestBody UserEntity userEntity) {
        UserEntity uEntity = userRepository.save(userEntity);
        return uEntity;
    }

    @PostMapping("/jpa/update")
    public UserEntity jpaUpdate(@RequestBody UserEntity userEntity) {
        UserEntity uEntity = userRepository.saveAndFlush(userEntity);
        return uEntity;
    }

    @DeleteMapping("/jpa/delete")
    @Transactional
    public String jpaDelete(Integer userId){
        userRepository.deleteById(userId);
        return "1";
    }

    @GetMapping("/jpa/query")
    public UserEntity jpaQuery(Integer userId) {
        UserEntity userEntity = userRepository.queryByUserId(userId);
        return userEntity;
    }
}
