package com.example.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/hi")
public class HiController{

    private final WebClient webClient;

    public HiController(WebClient webClient) {
        this.webClient = webClient.mutate().build();
    }

    @GetMapping("/webClient/query")
    public String hi(){
        return "spring boot!";
    }

    @GetMapping("/webClient/test")
    public String webClientTest(){
        Mono<String> mono = webClient.get().uri("http://localhost:8080/hi/webClient/query").retrieve().bodyToMono(String.class);
        return mono.block();
    }
}
