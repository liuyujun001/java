package com.example.springboot.controller;

import io.netty.channel.ChannelOption;
import io.netty.channel.ConnectTimeoutException;
import io.netty.handler.timeout.ReadTimeoutException;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.client.reactive.ReactorResourceFactory;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.resources.ConnectionProvider;
import reactor.netty.resources.LoopResources;
import reactor.retry.Retry;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

@Configuration
public class WebClientConfig {

    @Bean
    @Primary
    public ReactorResourceFactory resourceFactory() {
        ReactorResourceFactory factory = new ReactorResourceFactory();
        factory.setUseGlobalResources(false);
        factory.setConnectionProvider(ConnectionProvider.builder("httpClient").metrics(true).maxConnections(16)
                .pendingAcquireTimeout(Duration.ofMillis(1000)).build());
        factory.setLoopResources(LoopResources.create("httpClient", 16, true));
        return factory;
    }
    //定义Retry策略
    @Bean
    @Primary
    public Retry<?> retry() {
        return Retry.anyOf(ReadTimeoutException.class, ConnectTimeoutException.class, WebClientResponseException.class)
                .fixedBackoff(Duration.ZERO)
                .retryMax(2)  //retry次数
                .doOnRetry((exception) -> {  //异常日志
                });
    }
    //定义WebClient
    @Bean
    @Primary
    public WebClient webClient(WebClient.Builder builder, ReactorResourceFactory resourceFactory) {
        Function<HttpClient, HttpClient> mapper = client ->
                client.tcpConfiguration(tcpClient ->
                        tcpClient.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 2000) //创建连接超时时间
                                .option(ChannelOption.TCP_NODELAY, true)
                                .doOnConnected(connection -> {  //链接策略
                                    connection.addHandlerLast(new ReadTimeoutHandler(2000, TimeUnit.MILLISECONDS));
                                    connection.addHandlerLast(new WriteTimeoutHandler(2000, TimeUnit.MILLISECONDS));
                                }))
                        .headers(headerBuilder -> {  //设置header属性
                            headerBuilder.set("Accept-Charset", "utf-8");
                            headerBuilder.set("Accept-Encoding", "gzip, x-gzip, deflate");
                            headerBuilder.set("ContentType", "text/plain; charset=utf-8");
                        }).keepAlive(true);
        ClientHttpConnector connector = new ReactorClientHttpConnector(resourceFactory, mapper);
        return builder.clientConnector(connector).build();
    }
}
