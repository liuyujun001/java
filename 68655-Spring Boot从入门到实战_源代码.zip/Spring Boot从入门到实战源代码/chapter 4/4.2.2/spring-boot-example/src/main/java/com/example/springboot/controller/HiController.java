package com.example.springboot.controller;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hi")
public class HiController{

    @Autowired
    private MongoTemplate mongoTemplate;

    @GetMapping("/mongo/add")
    public Document mongoAdd(String id) {
        BasicDBObject db = new BasicDBObject();
        db.put("_id", new ObjectId(id));
        mongoTemplate.insert(db, "pages");
        MongoCollection<Document> collection = mongoTemplate.getCollection("pages");
        Document document = collection.find(db).first();
        return document;
    }

    @GetMapping("/mongo/query")
    public Document mongoQuery(String id) {
        BasicDBObject db = new BasicDBObject();
        db.put("_id", new ObjectId(id));
        MongoCollection<Document> collection = mongoTemplate.getCollection("pages");
        Document document = collection.find(db).first();
        return document;
    }
}
