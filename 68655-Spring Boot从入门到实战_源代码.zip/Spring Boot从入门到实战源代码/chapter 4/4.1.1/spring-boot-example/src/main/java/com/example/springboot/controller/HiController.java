package com.example.springboot.controller;

import com.example.springboot.model.User;
import com.example.springboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hi")
public class HiController{
    @Autowired
    private UserService userService;

    @PostMapping("/add")
    public String add(@RequestBody User user){
        return userService.add(user);
    }

    @GetMapping("/findOne")
    public User findOne(Integer userId){
        return userService.findOne(userId);
    }

    @PostMapping("/update")
    public String update(@RequestBody User user){
        return userService.update(user);
    }

    @DeleteMapping("/delete")
    public String delete(Integer userId){
        return userService.delete(userId);
    }

    @GetMapping("/findAll")
    public List<User> findAll(){
        return userService.findAll();
    }

}
