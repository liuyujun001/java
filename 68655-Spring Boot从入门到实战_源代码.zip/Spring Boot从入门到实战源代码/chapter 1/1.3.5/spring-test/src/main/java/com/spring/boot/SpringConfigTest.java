package com.spring.boot;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

@EnableAspectJAutoProxy
@Configuration
@ComponentScan("com.spring.boot")
public class SpringConfigTest {
    @Bean
    public UserService userService() {
        return new UserService();
    }

    public static void main(String[] args) {
        //通过配置类获取Spring应用上下文
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigTest.class);
        UserService userService = context.getBean(UserService.class);
        userService.setId(1);
        userService.setName("zhangsan");
        userService.getUser();  //打印属性值
    }

}
