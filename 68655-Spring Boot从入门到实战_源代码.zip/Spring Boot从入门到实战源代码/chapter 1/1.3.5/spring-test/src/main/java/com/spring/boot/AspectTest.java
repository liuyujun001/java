package com.spring.boot;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectTest {
    //定义切点，对于@User注解的方法
    @Pointcut("@annotation(com.spring.boot.User)")
    public void pointCut() {}
    //在切点方法之前执行
    @Before("pointCut()")
    public void before() {
        System.out.println("before");
    }
    //处理真实方法
    @Around("pointCut()")
    public void around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        System.out.println("around before");
        proceedingJoinPoint.proceed();
        System.out.println("around after");
    }
    //在切点方法之后执行
    @After("pointCut()")
    public void after() {
        System.out.println("after");
    }
}
