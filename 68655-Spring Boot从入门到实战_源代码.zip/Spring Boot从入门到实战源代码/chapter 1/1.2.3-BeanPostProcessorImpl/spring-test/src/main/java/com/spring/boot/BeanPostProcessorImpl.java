package com.spring.boot;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class BeanPostProcessorImpl implements BeanPostProcessor {
    //实例化之前操作
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        //判断bean类型
        if(bean instanceof UserService){
            System.out.println("postProcessBeforeInitialization bean : " + beanName);
        }
        return bean;
    }
    //实例化之后操作
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        //判断bean类型
        if(bean instanceof UserService){
            System.out.println("postProcessAfterInitialization bean : " + beanName);
        }
        return bean;
    }

}
