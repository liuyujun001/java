package com.spring.boot;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringXmlTest {
    public static void main(String[] args) {
        //通过spring.xml获取Spring应用上下文
        ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        UserService userService = context.getBean("userService",UserService.class);
        userService.getUser();  //打印结果
    }
}
