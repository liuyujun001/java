package com.spring.boot;

public interface UserInterface {
    //声明方法
    public abstract void getUser();

}
