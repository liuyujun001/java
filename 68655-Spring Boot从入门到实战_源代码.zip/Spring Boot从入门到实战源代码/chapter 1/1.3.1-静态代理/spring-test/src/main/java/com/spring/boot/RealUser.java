package com.spring.boot;

public class RealUser implements UserInterface {
    @Override
    public void getUser() {
        //新建UserService对象
        System.out.println("真实用户角色执行！");
        UserService userService = new UserService();
        userService.setId(1);
        userService.setName("zhangsan");
        userService.getUser();
    }

}
