package com.spring.boot;

public class SpringProxyTest {
    public static void main(String[] args) {
        UserInterface realUser = new RealUser();
        //传入真实对象RealUser
        UserProxy userProxy = new UserProxy(realUser);
        userProxy.getUser();
    }

}
