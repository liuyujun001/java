package com.spring.boot;

public class UserProxy implements UserInterface {
    private UserInterface userInterface;
    //构造方法传入UserInterface类型参数
    public UserProxy(UserInterface userInterface) {
        this.userInterface = userInterface;
    }
    //实现getUser方法，在执行方法前后进行额外操作
    @Override
    public void getUser() {
        doBefore();
        userInterface.getUser();
        doAfter();
    }
    //真实方法执行前操作
    private void doBefore() {
        System.out.println("代理类开始执行");
    }
    //真实方法执行后操作
    private void doAfter() {
        System.out.println("代理类结束执行");
    }

}
