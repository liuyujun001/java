package com.spring.boot;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class UserServiceProxy implements InvocationHandler {
    private Object target;
    //构造方法
    public UserServiceProxy(Object target) {
        this.target = target;
    }
    //通过Proxy动态生成代理类对象
    public <T> T getProxy() {
        return (T) Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), this);
    }
    //动态执行方法
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("JDK proxy before");
        method.invoke(target, args);
        System.out.println("JDK proxy after");
        return null;
    }
}
