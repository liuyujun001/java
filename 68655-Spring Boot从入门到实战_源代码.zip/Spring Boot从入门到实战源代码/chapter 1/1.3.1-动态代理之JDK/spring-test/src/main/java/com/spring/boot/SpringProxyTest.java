package com.spring.boot;

public class SpringProxyTest {
    public static void main(String[] args) {
        //通过代理类生成UserServiceInterface接口类型对象
        UserServiceInterface userServiceInterface = new UserServiceProxy(new UserServiceImpl()).getProxy();
        userServiceInterface.getUser();  //调用getUser方法
    }

}
