package com.spring.boot;

import net.sf.cglib.proxy.Enhancer;

public class SpringProxyTest {
    public static void main(String[] args) {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(UserServiceImpl.class);  //设置父类
        enhancer.setCallback(new UserMethodInterceptor());  //设置拦截器
        UserServiceImpl userServiceImpl = (UserServiceImpl) enhancer.create();  //创建对象
        userServiceImpl.getUser();  //调用getUser方法
    }
}
