package com.spring.boot;

public class UserServiceImpl implements UserServiceInterface {
    @Override
    public void getUser() {
        System.out.println("zhangsan");  //实现getUser方法
    }
}
