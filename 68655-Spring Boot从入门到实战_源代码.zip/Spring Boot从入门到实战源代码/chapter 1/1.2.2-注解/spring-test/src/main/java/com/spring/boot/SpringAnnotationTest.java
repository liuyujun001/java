package com.spring.boot;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.spring.boot")
public class SpringAnnotationTest {
    public static void main(String[] args) {
        //通过注解类获取应用上下文
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringAnnotationTest.class);
        //获取UserService对象
        UserService userService = context.getBean(UserService.class);
        userService.setId(1);
        userService.setName("zhangsan");
        userService.getUser();   //调用方法，打印属性值
    }

}
