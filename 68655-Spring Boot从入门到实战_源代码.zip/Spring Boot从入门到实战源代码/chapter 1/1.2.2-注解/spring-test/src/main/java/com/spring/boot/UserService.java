package com.spring.boot;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    private Integer id;  //用户id
    private String name;  //用户名称
    //getter和setter方法
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    //打印属性值
    public void getUser() {
        System.out.println("id:"+this.id);
        System.out.println("name:"+this.name);
    }

}
