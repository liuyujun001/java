package com.spring.boot;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;

@Component
public class BeanFactoryPostProcessorImpl implements BeanFactoryPostProcessor {
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        //获取UserService的BeanDefinition
        BeanDefinition beanDefinition = beanFactory.getBeanDefinition("userService");
        //修改Scope属性
        beanDefinition.setScope("prototype");
        System.out.println(beanDefinition. getScope());
    }
}

