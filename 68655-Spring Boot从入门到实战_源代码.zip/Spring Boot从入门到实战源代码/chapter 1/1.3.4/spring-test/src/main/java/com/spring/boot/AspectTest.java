package com.spring.boot;

public class AspectTest {
    //方法执行前操作
    public void before() {
        System.out.println("before");
    }
    //方法执行后操作
    public void after() {
        System.out.println("after");
    }
    //方法环绕操作
    public void around() {
        System.out.println("around");
    }

}
