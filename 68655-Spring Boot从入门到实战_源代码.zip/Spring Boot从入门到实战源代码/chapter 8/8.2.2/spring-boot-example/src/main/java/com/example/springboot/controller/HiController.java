package com.example.springboot.controller;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.search.Search;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/hi")
public class HiController{

    public static final String BUSINESS_CODE_METRIC = "http.code.total";

    @Resource
    private MeterRegistry meterRegistry;

    @GetMapping("/springBoot")
    public String hi(){
        increment("S001","hi");
        return "hi spring boot!";
    }

    private void increment(String code, String operation) {
        //定义tag
        Tags tags = Tags.of(
                Tag.of("code", code),
                Tag.of("handler", operation));
        //定义Counter
        Counter counter = Search.in(this.meterRegistry).name(BUSINESS_CODE_METRIC).tags(tags).counter();
        if (counter == null) {
            counter = this.meterRegistry.counter(BUSINESS_CODE_METRIC, tags);
        }
        //Counter计数加一
        counter.increment();
    }

}
