package com.example.springboot.endpoint;

import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.boot.actuate.endpoint.web.annotation.WebEndpoint;
import org.springframework.stereotype.Component;

@WebEndpoint(id="userEndpoint")
@Component
public class UserEndpoint {

    @ReadOperation
    public String readUserEndpoint(){
        return "test read userEndpoint!";
    }

    @WriteOperation
    public String writeUserEndpoint(){
        return "test write userEndpoint!";
    }

    @DeleteOperation
    public String deleteUserEndpoint(){
        return "test delete userEndpoint!";
    }

}
