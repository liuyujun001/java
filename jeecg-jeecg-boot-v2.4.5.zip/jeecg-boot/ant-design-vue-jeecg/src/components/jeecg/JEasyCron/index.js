// 原开源项目地址：https://gitee.com/toktok/easy-cron

import InputCron from './InputCron.vue'

InputCron.name = 'JEasyCron'
export default InputCron